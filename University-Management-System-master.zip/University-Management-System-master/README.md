# University-Management-System
A MySQL-PHP based university management system 

We have created a University Management System, which can be used by students as well as teachers to keep track of and register for courses, grade students and trace results across various semesters. 

The project makes use of a MySQL Database, Apache Server, PHP, HTML and CSS. The system makes use of MySQL to store the user information, Apache server to host the database, PHP to query the database, and HTML/CSS for creating a user friendly interface. Since we have used a MySQL database, the project doesn’t face concurrency problems, and multiple terminals can be used at once. 
