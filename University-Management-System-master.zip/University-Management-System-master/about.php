<html>
<head>
  <title>About Us</title>
</head>
<center>
<style>
a:visited {
    color: white;
}
#background {
    width: 100%; 
    height: 100%; 
    position: fixed; 
    left: 0px; 
    top: 0px; 
    z-index: -1;
}

.stretch {
    width:100%;
    height:100%;
}
ul {
  text-align: left;
}
</style>
<body link="yellow">
<div id="background">
    <img src="Images/bkgrnd.jpg" class="stretch" alt="" />
</div>
<font color="white">
  <h1>About Us</h1>
  <a title="About Us"><img class="img-circle" src="Images/about-us.png" width="250" height="200"/></a><br/>
  <p  align="left" style="text-indent: 4em;"><b>Netaji Subhas Technological University of Delhi</b> is devoted to excellence in teaching, learning, and research, and to developing leaders in many disciplines who make a difference globally. The University, based in Dwarka, New Delhi, has an enrollment of over 4,000 degree candidates, including undergraduate, graduate, and professional students. NSTUD has got more than 60,000 alumni around the country.</p>
  
  <p align="left" >We offer the following services: </p>
  <h4 align="left">Student: </h4>
  <p align="left"> NSTUD has been admitting students to its undergraduate programmes on the basis of marks obtained by them in the Joint Entrance Examination (JEE) - MAIN, which is been conducted by Central Board of Secondary Education (CBSE) every year. Courses on offer are:<br></p>
  <ul>
              <li><a>Electronics and Communication Engineering</a></li>
              <li><a>Computer Engineering</a></li>
              <li><a>Instrumentation and Control Engineering</a></li>
              <li><a>Manufacturing Process and Automation Engineering</a></li>
              <li><a>Information Technology</a></li>
              <li><a>Bio-Technology</a></li>
  </ul>
  <p align="left">For getting in any of the above courses, contact Admin directly:<br>Email: admin@nstud.co.in</p>
  <h4 align="left">Teachers: </h4>
  <p align="left">To join the experienced team of the faculty members of NSTUD, contact Admin :<br>Email: admin@nstud.co.in</p><br><br>
  

   <h3>Contact Details:</h3>
   <p>
         Sector-3 <br>Dwarka, Delhi 110078<br>
   </p>
   <p> 
   <abbr title="Phone">&nbsp;L</abbr>: 25099043 (Academic)<br>
   <abbr title="Phone">&nbsp;L</abbr>: 25099020 (Administration)<br>
   <abbr title="Phone">&nbsp;L</abbr>: 25099050 (Exchange)<br>
   </i><abbr title="Phone">&nbsp;L</abbr>: 25099025, 25099022 (Fax)<br>
   </p>
   <p> You can also mail us at admin@nstud.co.in</p>

  <a href="home.php">Go Back</a></br>
</font>
</center>
